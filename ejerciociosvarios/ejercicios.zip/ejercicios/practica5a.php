<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="practica5a-resultado.php" method="post">
        <h1>Conversor de euro a pesetas</h1>
        <label for="inpu"></label>
        <input type="text" id="inpu" name="euros">
        <input type="submit" value="Convertir">
    </form>
   

</body>
</html>